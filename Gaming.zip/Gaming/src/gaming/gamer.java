
package gaming;


public class gamer {
    
    public int gamer_id;
    public String name;
    
    
    public gamer(){
    
    }

    public int getGamer_id() {
        return gamer_id;
    }

    public void setGamer_id(int gamer_id) {
        this.gamer_id = gamer_id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
    
}
