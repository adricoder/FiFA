package gaming;

public class Gaming {

    public Gaming(){
    
    }
    public static void main(String[] args) {
    
    }
    
}
